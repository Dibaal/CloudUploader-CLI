#!/bin/bash

# Author: Dibaal Akari
# Created: 14/01/2024
# Last Modified: 14th Jan 2024

# Description:
# The script ensures users can easily download, install, and execute the cloud  # uploader tool.

# Usage: ./install.sh


# Define where to install
INSTALL_DIR="/usr/local/bin"

# Copy the script to the install directory
cp clouduploader.sh "$INSTALL_DIR/clouduploader"

# Make the script executable
chmod 744 "$INSTALL_DIR/clouduploader"

echo "CloudUploader installed successfully."
